```markdown
# Design System Document: The High-End Editorial

## 1. Overview & Creative North Star
**Creative North Star: "The Modern Archivist"**

This design system moves beyond the generic "portfolio" template to create a digital environment that feels like a curated literary journal. We are rejecting the rigid, boxy constraints of traditional web design in favor of **Organic Editorialism**. 

To achieve this, we leverage intentional asymmetry—placing oversized serif headings against wide-margined body text—to create a rhythm that feels human and authored. By utilizing a "paper-on-paper" layering philosophy, we replace harsh lines with tonal depth, ensuring the writer's work remains the focal point while the interface recedes into a sophisticated, atmospheric backdrop.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a high-contrast, academic sophistication: Deep Burgundy (`primary`), Ink-like Charcoals (`tertiary`), and warm Off-Whites (`surface`).

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for defining sections. We define boundaries through **Background Shifts**.
*   **The Transition:** Use `surface` as your base. To define a new section (e.g., a "Selected Works" area), shift the background to `surface-container-low`.
*   **The Nested Depth:** Create importance by "stacking." A card should not have a border; it should be a `surface-container-lowest` shape sitting on a `surface-container-high` background. This mimics the physical layering of fine stationery.

### Glass & Gradients
To avoid a "flat" digital feel, floating elements (like navigation bars or hovering bio-cards) must use **Glassmorphism**:
*   **Tokens:** Use `surface` at 80% opacity with a `backdrop-blur` of 20px. 
*   **Signature Textures:** For high-impact CTAs or Hero section backgrounds, apply a subtle linear gradient transitioning from `primary` (#4d0408) to `primary_container` (#6b1b1b) at a 135-degree angle. This adds "visual soul" and a velvet-like depth.

---

### 3. Typography
Our typography is a conversation between the classic and the contemporary.

*   **Display & Headlines (Newsreader):** This serif is our "Voice." Use `display-lg` for the writer’s name or main hook. Its high x-height and elegant serifs should be given massive breathing room (minimum 80px top/bottom margin).
*   **Body & Labels (Manrope):** This sans-serif is our "Utility." It provides a clean, modern counter-balance to the serif. 
*   **Hierarchy Tip:** Always use `on_surface_variant` for body text to reduce eye strain against the off-white backgrounds, reserving `on_surface` (true charcoal) for bolded highlights or titles.

---

## 4. Elevation & Depth
In this design system, shadows are an atmosphere, not a structure.

*   **Tonal Layering:** Depth is achieved by "stacking" surface tiers. Place `surface_container_lowest` (the brightest white) on top of `surface_container` to create a natural "lift."
*   **Ambient Shadows:** If a floating element (like a modal) requires a shadow, it must be "Ambient."
    *   **Spec:** `0px 24px 48px rgba(26, 28, 27, 0.06)`. 
    *   The shadow color is derived from `on_surface`, ensuring it looks like a natural light occlusion rather than a "drop shadow" effect.
*   **The Ghost Border:** If a boundary is required for accessibility in input fields, use a **Ghost Border**: `outline-variant` at 20% opacity. Never use 100% opacity borders.

---

## 5. Components

### Buttons
*   **Primary:** A solid `primary` fill with `on_primary` text. Use `rounded-md` (0.375rem). Apply the signature gradient on hover to simulate a "glow."
*   **Secondary:** No fill. Use a `Ghost Border` and `on_surface` text.
*   **Tertiary:** Text-only, using `label-md` in all-caps with 0.05em letter spacing for an editorial look.

### Input Fields
*   **Style:** Minimalist. Use `surface_container_low` as the background with a 2px bottom-border only (using `outline_variant`). 
*   **Focus State:** Transition the bottom border to `primary` and subtly shift the background to `surface_container_high`.

### Editorial Cards
*   **Rule:** Forbid divider lines. Separate the "Article Title" from the "Excerpt" using vertical whitespace (e.g., 24px).
*   **Interaction:** On hover, the card should not "pop" up; instead, the background should shift from `surface` to `surface_container_low` with a soft 300ms ease.

### The "Manuscript" List
*   For bibliography or article lists, use `body-md` for the title and `label-sm` (in `on_surface_variant`) for the date. Align dates to a right-hand gutter, creating a clean vertical axis of whitespace between the text and the metadata.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace Asymmetry:** Place a large `display-md` headline on the left and a narrow column of `body-lg` text on the right. 
*   **Prioritize Whitespace:** If you think there is enough space, add 20% more. This is a writer's space; it needs "room to breathe."
*   **Use Subtle Micro-interactions:** Text links should have a `primary` underline that grows from 1px to 2px on hover.

### Don’t:
*   **Don't use Dividers:** Never use a horizontal line to separate content. Use a background color change or 64px+ of vertical space.
*   **Don't use Pure Black:** Always use `on_surface` (#1a1c1b) for text. Pure black is too harsh for an editorial experience.
*   **Don't Over-round:** Keep to `md` (0.375rem) or `lg` (0.5rem). Avoid `full` rounding except for very small tags; we want the system to feel structured and professional, not "bubbly."

---

## 7. Signature Element: The "Marginalia"
As a writer-focused system, use the `label-sm` typography and `tertiary` color to create "Marginalia"—small notes or citations placed in the wide gutters of the layout. This breaks the grid and reinforces the "The Modern Archivist" persona.```